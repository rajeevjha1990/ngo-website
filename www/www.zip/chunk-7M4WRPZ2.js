import{a}from"./chunk-E7ZOKENL.js";import"./chunk-B7O3QC5Z.js";export{a as startFocusVisible};
