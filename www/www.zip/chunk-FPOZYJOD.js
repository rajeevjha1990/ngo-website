import{a as r}from"./chunk-CKP3SGE2.js";var n=()=>{if(r!==void 0)return r.Capacitor};export{n as a};
