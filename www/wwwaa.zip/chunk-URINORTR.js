import{b as a,c as b}from"./chunk-M2X7KQLB.js";import"./chunk-B7O3QC5Z.js";export{a as GESTURE_CONTROLLER,b as createGesture};
